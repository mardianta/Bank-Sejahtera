</main>

<footer>
    <p>&copy; <?php echo date('Y'); ?> Bank Sejahtera. Dibuat dengan PHP Native.</p>
</footer>

</body>
</html>